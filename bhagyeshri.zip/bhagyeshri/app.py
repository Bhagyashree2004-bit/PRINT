from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
try:
    import mysql.connector
except ModuleNotFoundError:
    raise SystemExit("Missing required package 'mysql-connector-python'.\nInstall it with:\n    pip install mysql-connector-python\nor\n    pip install -r requirements.txt")
from datetime import datetime, timedelta
import re

app = Flask(__name__)
app.config.from_object('config.Config')

def get_db_connection():
    return mysql.connector.connect(
        host=app.config['MYSQL_HOST'],
        user=app.config['MYSQL_USER'],
        password=app.config['MYSQL_PASSWORD'],
        database=app.config['MYSQL_DB']
    )

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match!', 'error')
            return redirect(url_for('register'))
        
        if len(password) < 6:
            flash('Password must be at least 6 characters long!', 'error')
            return redirect(url_for('register'))
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                'INSERT INTO users (username, email, password) VALUES (%s, %s, %s)',
                (username, email, password)
            )
            conn.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except mysql.connector.IntegrityError:
            flash('Username or email already exists!', 'error')
        finally:
            cursor.close()
            conn.close()
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute(
            'SELECT * FROM users WHERE email = %s AND password = %s',
            (email, password)
        )
        user = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password!', 'error')
    
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute('''
        SELECT *, TIMESTAMPDIFF(SECOND, NOW(), deadline) as seconds_remaining 
        FROM tasks 
        WHERE user_id = %s AND status = 'pending'
        ORDER BY deadline ASC
    ''', (session['user_id'],))
    tasks = cursor.fetchall()
    
    # Calculate countdown for each task
    for task in tasks:
        seconds = task['seconds_remaining']
        if seconds > 0:
            days = seconds // (24 * 3600)
            seconds %= (24 * 3600)
            hours = seconds // 3600
            seconds %= 3600
            minutes = seconds // 60
            seconds %= 60
            task['countdown'] = {
                'days': days,
                'hours': hours,
                'minutes': minutes,
                'seconds': seconds
            }
        else:
            task['countdown'] = {'days': 0, 'hours': 0, 'minutes': 0, 'seconds': 0}
            task['overdue'] = True
    
    cursor.execute('''
        SELECT COUNT(*) as count FROM tasks 
        WHERE user_id = %s AND status = 'pending' 
        AND deadline BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
    ''', (session['user_id'],))
    weekly_tasks = cursor.fetchone()
    
    cursor.close()
    conn.close()
    
    return render_template('dashboard.html', tasks=tasks, weekly_tasks=weekly_tasks['count'])

@app.route('/add_task', methods=['GET', 'POST'])
def add_task():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        deadline = request.form['deadline']
        reminder_type = request.form['reminder_type']
        reminder_interval = request.form['reminder_interval']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO tasks (user_id, title, description, deadline, reminder_type, reminder_interval)
            VALUES (%s, %s, %s, %s, %s, %s)
        ''', (session['user_id'], title, description, deadline, reminder_type, reminder_interval))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        flash('Task added successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('add_task.html')

@app.route('/edit_task/<int:task_id>', methods=['GET', 'POST'])
def edit_task(task_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        deadline = request.form['deadline']
        reminder_type = request.form['reminder_type']
        reminder_interval = request.form['reminder_interval']
        status = request.form['status']
        
        cursor.execute('''
            UPDATE tasks 
            SET title = %s, description = %s, deadline = %s, reminder_type = %s, reminder_interval = %s, status = %s
            WHERE id = %s AND user_id = %s
        ''', (title, description, deadline, reminder_type, reminder_interval, status, task_id, session['user_id']))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        flash('Task updated successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    cursor.execute('SELECT * FROM tasks WHERE id = %s AND user_id = %s', (task_id, session['user_id']))
    task = cursor.fetchone()
    cursor.close()
    conn.close()
    
    if not task:
        flash('Task not found!', 'error')
        return redirect(url_for('dashboard'))
    
    return render_template('edit_task.html', task=task)

@app.route('/delete_task/<int:task_id>')
def delete_task(task_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('DELETE FROM tasks WHERE id = %s AND user_id = %s', (task_id, session['user_id']))
    conn.commit()
    cursor.close()
    conn.close()
    
    flash('Task deleted successfully!', 'success')
    return redirect(url_for('dashboard'))

@app.route('/view_tasks')
def view_tasks():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute('''
        SELECT * FROM tasks 
        WHERE user_id = %s AND status = 'pending'
        ORDER BY deadline ASC
    ''', (session['user_id'],))
    pending_tasks = cursor.fetchall()
    
    cursor.execute('''
        SELECT * FROM tasks 
        WHERE user_id = %s AND status = 'completed'
        ORDER BY deadline DESC
    ''', (session['user_id'],))
    completed_tasks = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('view_task.html', pending_tasks=pending_tasks, completed_tasks=completed_tasks)

@app.route('/complete_task/<int:task_id>')
def complete_task(task_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        UPDATE tasks SET status = 'completed' 
        WHERE id = %s AND user_id = %s
    ''', (task_id, session['user_id']))
    
    conn.commit()
    cursor.close()
    conn.close()
    
    flash('Task marked as completed!', 'success')
    return redirect(url_for('view_tasks'))

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/complete_task_dashboard/<int:task_id>')
def complete_task_dashboard(task_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        UPDATE tasks SET status = 'completed' 
        WHERE id = %s AND user_id = %s
    ''', (task_id, session['user_id']))
    
    conn.commit()
    cursor.close()
    conn.close()
    
    flash('Task marked as completed! 🌸', 'success')
    return redirect(url_for('dashboard'))

# append small script to auto-hide flash messages after 3s for every HTML response
@app.after_request
def inject_auto_hide_flash(response):
    try:
        content_type = response.headers.get('Content-Type', '')
        if 'text/html' in content_type.lower():
            body = response.get_data(as_text=True)
            if '</body>' in body and 'data-auto-hide-flash' not in body:
                script = (
                    '<script data-auto-hide-flash>'
                    'document.addEventListener("DOMContentLoaded", function(){'
                    '  var flashes = Array.from(document.querySelectorAll(".flash-message"));'
                    '  flashes.forEach(function(f){'
                    '    f.style.transition = "opacity 0.6s ease, transform 0.6s ease";'
                    '    f.addEventListener("click", function(){ if(f.parentNode) f.parentNode.removeChild(f); });'
                    '  });'
                    '  if(flashes.length){ setTimeout(function(){ flashes.forEach(function(f){ f.style.opacity="0"; f.style.transform="translateY(-10px)"; setTimeout(function(){ if(f.parentNode) f.parentNode.removeChild(f); }, 700); }); }, 3000); }'
                    '});'
                    '</script>'
                )
                body = body.replace('</body>', script + '</body>')
                response.set_data(body)
    except Exception:
        pass
    return response

if __name__ == '__main__':
    app.run(debug=True)